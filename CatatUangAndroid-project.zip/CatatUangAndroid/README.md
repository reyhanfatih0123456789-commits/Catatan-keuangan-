# Catat Uang Offline (Android)

Aplikasi pencatat pemasukan/pengeluaran harian berbahasa Indonesia. Data tersimpan lokal dalam SQLite pada perangkat. Tidak ada permission INTERNET dan tidak memakai API/Firebase.

## Fitur
- Saldo otomatis, total pemasukan dan pengeluaran
- Catat transaksi dengan tanggal, kategori, jumlah, dan keterangan
- Riwayat per tanggal; ketuk transaksi untuk menghapus
- Ringkasan total bulan berjalan
- SQLite lokal, tidak perlu akun/internet

## Membuat APK
1. Buka folder project ini menggunakan Android Studio versi terbaru.
2. Tunggu Gradle sync selesai (build pertama memerlukan internet untuk mengunduh Android Gradle Plugin/SDK jika belum tersedia).
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.
5. Salin APK ke HP Android dan buka untuk memasang. Jika diminta, izinkan pemasangan dari sumber tersebut.

## Catatan
- Ini project sumber Android Studio; lingkungan pembuatan file ini tidak menyediakan Android SDK/Gradle untuk mengompilasi dan menguji APK secara langsung.
- Database disimpan pada data aplikasi. Menghapus aplikasi dapat menghapus data; ekspor/impor cadangan belum termasuk pada versi awal.
