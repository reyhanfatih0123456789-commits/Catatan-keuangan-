package id.offline.catatuang

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class TransactionRow(val id: Long, val kind: String, val amount: Long, val category: String, val note: String, val date: String)

class FinanceDb(context: Context) : SQLiteOpenHelper(context, "catat_uang.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, amount INTEGER NOT NULL, category TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', date TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_transactions_date ON transactions(date)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }
    fun insert(kind: String, amount: Long, category: String, note: String, date: String) {
        val values = ContentValues().apply { put("kind", kind); put("amount", amount); put("category", category); put("note", note); put("date", date) }
        writableDatabase.insertOrThrow("transactions", null, values)
    }
    fun delete(id: Long) { writableDatabase.delete("transactions", "id=?", arrayOf(id.toString())) }
    fun balance(): Long = total("MASUK") - total("KELUAR")
    fun total(kind: String): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind=?", arrayOf(kind)).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    fun monthTotal(kind: String, month: String): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE kind=? AND date LIKE ?", arrayOf(kind, "$month-%")).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    fun transactions(date: String): List<TransactionRow> {
        val result = mutableListOf<TransactionRow>()
        readableDatabase.rawQuery("SELECT id,kind,amount,category,note,date FROM transactions WHERE date=? ORDER BY id DESC", arrayOf(date)).use { c ->
            while (c.moveToNext()) result.add(TransactionRow(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5)))
        }
        return result
    }
}
