package id.offline.catatuang

import android.app.Activity
import android.app.DatePickerDialog
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: FinanceDb
    private lateinit var root: LinearLayout
    private val locale = Locale("id", "ID")
    private val rupiah = NumberFormat.getCurrencyInstance(locale)
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private var chosenDate = dateFmt.format(Calendar.getInstance().time)
    private val green = Color.rgb(22, 101, 52)
    private val ink = Color.rgb(31, 41, 55)
    private val muted = Color.rgb(107, 114, 128)
    private val pale = Color.rgb(240, 253, 244)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = FinanceDb(this)
        showHome()
    }

    private fun money(n: Long) = rupiah.format(n).replace(",00", "")
    private fun text(value: String, size: Float = 15f, color: Int = ink, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 5, 0, 5)
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); setBackgroundColor(Color.WHITE)
        elevation = 2f
        val p = (parent as? ViewGroup)
    }
    private fun showHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247, 250, 248)); setPadding(18, 18, 18, 12) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("Catat Uang", 27f, green, true))
        content.addView(text("Pencatat keuangan harian • Offline", 13f, muted))
        val summary = card().apply { setBackgroundColor(pale); addView(text("SISA SALDO", 12f, green, true)); addView(text(money(db.balance()), 28f, green, true)) }
        content.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 18, 0, 12) })
        val totals = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val inc = card().apply { addView(text("Pemasukan", 13f, muted)); addView(text(money(db.total("MASUK")), 17f, green, true)) }
        val out = card().apply { addView(text("Pengeluaran", 13f, muted)); addView(text(money(db.total("KELUAR")), 17f, Color.rgb(185, 28, 28), true)) }
        totals.addView(inc, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0,0,6,0) })
        totals.addView(out, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(6,0,0,0) })
        content.addView(totals)
        content.addView(button("＋ Catat Pemasukan") { addTransaction("MASUK") })
        content.addView(button("－ Catat Pengeluaran") { addTransaction("KELUAR") })
        content.addView(button("Pilih tanggal: $chosenDate") { pickDate { chosenDate = it; showHome() } })
        content.addView(text("Riwayat Transaksi — $chosenDate", 18f, ink, true).apply { setPadding(0, 18, 0, 6) })
        val rows = db.transactions(chosenDate)
        if (rows.isEmpty()) content.addView(text("Belum ada transaksi pada tanggal ini.", 14f, muted))
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(Color.WHITE) }
            val sign = if (row.kind == "MASUK") "+" else "−"
            val col = if (row.kind == "MASUK") green else Color.rgb(185, 28, 28)
            line.addView(text("$sign ${money(row.amount)}", 17f, col, true))
            line.addView(text("${row.category} • ${row.note.ifBlank { "Tanpa keterangan" }}", 13f, muted))
            line.addView(text("${row.date}   |   Ketuk untuk menghapus", 11f, muted))
            line.setOnClickListener {
                AlertDialog.Builder(this).setTitle("Hapus transaksi?").setMessage("Catatan ${money(row.amount)} akan dihapus dari HP ini.")
                    .setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> db.delete(row.id); showHome() }.show()
            }
            content.addView(line, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) })
        }
        content.addView(button("Ringkasan bulan ini") { showMonthly() })
        content.addView(text("Data tersimpan di HP. Aplikasi tidak meminta koneksi internet.", 12f, muted).apply { setPadding(0, 16, 0, 8) })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun pickDate(onPicked: (String) -> Unit) {
        val cal = Calendar.getInstance()
        try { cal.time = dateFmt.parse(chosenDate)!! } catch (_: Exception) {}
        DatePickerDialog(this, { _, y, m, d -> onPicked(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)) }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addTransaction(kind: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 8, 22, 0) }
        val amount = EditText(this).apply { hint = "Jumlah (contoh: 25000)"; inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
        val category = EditText(this).apply { hint = "Kategori (makan, gaji, dll.)"; setSingleLine(true) }
        val note = EditText(this).apply { hint = "Keterangan (opsional)"; setSingleLine(true) }
        val date = TextView(this).apply { text = "Tanggal: $chosenDate (ketuk untuk mengubah)"; textSize = 15f; setPadding(0, 16, 0, 16); setOnClickListener { pickDate { chosenDate = it; text = "Tanggal: $chosenDate (ketuk untuk mengubah)" } } }
        box.addView(amount); box.addView(category); box.addView(note); box.addView(date)
        AlertDialog.Builder(this).setTitle(if (kind == "MASUK") "Catat Pemasukan" else "Catat Pengeluaran").setView(box)
            .setNegativeButton("Batal", null).setPositiveButton("Simpan", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val n = amount.text.toString().trim().toLongOrNull()
                        if (n == null || n <= 0) { amount.error = "Masukkan jumlah lebih dari 0"; return@setOnClickListener }
                        if (category.text.toString().trim().isEmpty()) { category.error = "Kategori wajib diisi"; return@setOnClickListener }
                        db.insert(kind, n, category.text.toString().trim(), note.text.toString().trim(), chosenDate)
                        dialog.dismiss(); showHome()
                    }
                }
                dialog.show()
            }
    }

    private fun showMonthly() {
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Calendar.getInstance().time)
        val incoming = db.monthTotal("MASUK", month)
        val outgoing = db.monthTotal("KELUAR", month)
        AlertDialog.Builder(this).setTitle("Ringkasan $month")
            .setMessage("Total pemasukan: ${money(incoming)}\nTotal pengeluaran: ${money(outgoing)}\nSelisih: ${money(incoming - outgoing)}")
            .setPositiveButton("Tutup", null).show()
    }

    override fun onDestroy() { if (::db.isInitialized) db.close(); super.onDestroy() }
}
